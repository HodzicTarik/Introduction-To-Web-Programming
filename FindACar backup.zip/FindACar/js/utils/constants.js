if (typeof Constants === "undefined") {
  var Constants = {
    PROJECT_BASE_URL: "http://localhost/TarikHodzic/Introduction-To-Web-Programming/FindACar/rest/",
    ADMIN_ROLE: "admin",
    USER_ROLE: "user"
  };
}
