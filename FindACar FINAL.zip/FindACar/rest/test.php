<?php
/*require_once 'dao/CarsDAO.php';
$dao = new CarsDAO();
$result = $dao->getAll();
echo "<pre>";
print_r($result);
echo "</pre>";

$db = getDatabaseConnection();
$res = $db->query("SHOW TABLES")->fetchAll();
echo "<pre>";
print_r($res);
echo "</pre>";*/

echo "Test";
