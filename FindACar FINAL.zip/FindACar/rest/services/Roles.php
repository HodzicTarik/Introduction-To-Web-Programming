<?php
class Roles {
    const USER = "user";
    const ADMIN = "admin";
}
